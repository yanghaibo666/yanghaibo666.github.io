[MagicaVoxel : 8-bit Voxel Editor & Renderer created by ephtracy]
================================
date    : 11/11/2019

version : 0.99.4.2

os      : Win32, win64, MacOS 10.7+

website : https://ephtracy.github.io/

twitter : @ ephtracy

[Credits]
================================
Intel® Open Image Denoise : https://openimagedenoise.github.io
HDRi : HDRI-Hub Free Samples : https://www.hdri-hub.com/hdrishop/freesamples
Icon : Font Awesome Free Version : https://fontawesome.com
Icon : Google Material Design : https://material.io/tools/icons/?style=baseline
Icon : Ionicons : https://ionicons.com
SDF Font : https://github.com/evanw/font-texture-generator